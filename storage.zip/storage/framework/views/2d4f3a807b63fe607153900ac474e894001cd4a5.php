<?php $__env->startSection('header'); ?>
<link href="<?php echo e(URL::asset('css/lib/font-awesome/fontawesome-all.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$directory = 'Kategori';
?>
<div class="row page-titles">
	<div class="col-md-5 align-self-center">
		<h3 class="text-primary"><?php echo e($directory); ?></h3> </div>
		<div class="col-md-7 align-self-center">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
				<li class="breadcrumb-item active"><?php echo e($directory); ?></li>
			</ol>
		</div>
	</div>
	<!-- End Bread crumb -->
	<!-- Container fluid  -->
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<?php if(session('message')): ?>
					<div class="alert alert-<?php echo e(session('status')); ?> alert-dismissible fade show text-dark" role="alert">
						<strong >Pesan : </strong> <?php echo e(session('message')); ?>

						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
				<?php endif; ?>
				
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-title">
						<h4>Input Kategori</h4>
						<hr>
					</div>
					<div class="card-body">
						<div class="basic-form">
							<form action="<?php echo e(url('kategori/add')); ?>" method="post">
								<?php echo e(csrf_field()); ?>

								<div class="row">
									<div class="col-md-6">
										<div class="form-group">
											<label for="exampleInputEmail1">Nama Kategori</label>
											<input type="text" name="kategori" class="form-control input-flat" placeholder="Nama Kategori (EX: olahraga)" onkeyup="gurl()">
										</div>
									</div>
									<div class="col-md-6">
										<div class="form-group">
											<label for="exampleInputEmail1">URL</label>
											<input type="text" name="url" class="form-control input-flat" placeholder="" disabled="">
										</div>
									</div>
								</div>
								<button type="submit" class="btn btn-primary">Submit</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-title">
						Data Nama Kategori
					</div>
					<div class="card-body">
						<table class="table">
							<thead class="thead-default">
								<tr>
									<td>No</td>
									<td>Nama Kategori</td>
									<td>URL</td>
									<td>Action</td>
								</tr>
							</thead>
						</table>
					</div>
				</div>
				<?php echo $data; ?>

			</div>
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
	<script src="js/lib/datatables/datatables.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script src="js/lib/datatables/datatables-init.js"></script>
	<script>
		$(document).ready(function(){
			var url = window.location.href;
			var arr = url.split("/");
			var url_result = arr[0] + "//" + arr[2];
			$("input[name='url']").val(url_result);

			// Data Table
			var data = <?php echo $data; ?>

			$('.table').DataTable({
				data: data,
				columns:[
					{data: 'id'},
					{data: 'nama_kategori'},
					{
						data: 'nama_kategori',
						render: function(data, type, row){
							return agurl(data);
						}
					},
					{
				      data: 'id',
				      render: function(data, type, row){
				      	return '<div class="dropdown"><button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Ubah / Hapus</button><div class="dropdown-menu" aria-labelledby="dropdownMenuButton"><a class="dropdown-item" href="<?php echo e(url('kategori/edit/')); ?>">Edit</a><a class="dropdown-item" href="<?php echo e(url('kategori/destroy')); ?>/'+data+'">Hapus action</a></div></div>'
				      }
				    }
				]
			});
		});
		function gurl(){
			var url = window.location.href;
			var arr = url.split("/");
			var input_url = encodeURIComponent($("input[name='kategori']").val());
			var url_result = arr[0] + "//" + arr[2] + "/" + input_url;
			$("input[name='url']").val(url_result);
		}
		function agurl(str_url){
			var url = window.location.href;
			var arr = url.split("/");
			var input_url = encodeURIComponent(str_url);
			var url_result = arr[0] + "//" + arr[2] + "/" + input_url;
			return url_result;
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>