<html>
<head>
	<meta charset="UTF-8">
	<title>MamujuToday.com</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/mnews/mnews.css')); ?>">
	<script src="<?php echo e(asset('js/lib/jquery/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/stickyjs/jquery.sticky.js')); ?>"></script>
</head>
<body style="height: 1500px">
	<nav class="navbar navbar-light nav-header">
		<a class="navbar-brand" href="#">
			<img class="logo-header" src="<?php echo e(asset('images/mnews/logo-2.png')); ?>" alt="">
		</a>
	</nav>
	<nav class="navbar navbar-expand-lg navbar-light sub-nav-header" id="stick-sub-nav-header">
		<div class="container">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">News</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Ragam</a>
					</li>
					<li class="nav-item">
						<a class="nav-link disabled" href="#">Olahraga</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<div class="container">
		<div class="row">
			<div class="col-md-3 content-left">
				<div class="list-berita-title">INFOGRAFIS</div>
				<div class="list-berita">
					<div class="content-list">
						<img src="<?php echo e(asset('images/watch.jpg')); ?>" alt="" class="content-list-img">
						<div class="content-list-kategori">PIDANA</div>
						<div class="content-list-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
					</div>
					<div class="content-list">
						<img src="<?php echo e(asset('images/watch.jpg')); ?>" alt="" class="content-list-img">
						<div class="content-list-kategori">PIDANA</div>
						<div class="content-list-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
					</div>
				</div>
			</div>
			<div class="col-md-6 content-center">
				<div class="slider">
					<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<?php
							$no = 0;
							?>
							<?php $__currentLoopData = $berita_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($no == 0): ?>
							<div class="carousel-item active">
							<?php else: ?>
							<div class="carousel-item">
							<?php endif; ?>
								<?php if($slider->source_type == 'gambar'): ?>
									<img src="<?php echo e($slider->source); ?>" alt="Los Angeles" class="h-300">
								<?php elseif($slider->source_type == 'video'): ?>
									<object data="<?php echo e($slider->source); ?>" style="min-width: 600px;width: 100%;min-height: 300px;">
									</object>
								<?php elseif($slider->source_type == 'embed'): ?>
									<div class="embed">
										<?php echo $slider->source; ?>

									</div>
								<?php endif; ?>
								<div class="carousel-caption d-none d-md-block">
									<h5><?php echo e($slider->judul); ?></h5>
								</div>
							</div>
							<?php
							$no = $no + 1;
							?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						</a>
						<a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						</a>
					</div>
				</div>
				<div class="content-news">
					<div class="content-title">TERKINI</div>
					<?php $__currentLoopData = $berita_terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($news->source_type == 'gambar'): ?>
							<div class="content-list <?php echo e($news->source_type); ?>" onclick="linked('<?php echo e(url('view/'.App\Model\Kategori::detail($news->id_kategori)->nama_kategori.'/'.$news->url)); ?>');">
								<div class="content-image">
									<img src="<?php echo e($news->source); ?>" alt="">
								</div>
								<div class="content-list-title"><?php echo e($news->judul); ?></div>
								<div class="content-list-desc"><?php echo str_limit(strip_tags($news->konten), 100); ?></div>
								<div class="content-list-kategori"><?php echo e(App\Model\Kategori::detail($news->id_kategori)->nama_kategori); ?></div>
							</div>
						<?php elseif($news->source_type == 'video'): ?>
							<div class="content-list <?php echo e($news->source_type); ?>" onclick="linked('<?php echo e(url('view/'.App\Model\Kategori::detail($news->id_kategori)->nama_kategori.'/'.$news->url)); ?>');">
								<div class="content-video">
									<object data="<?php echo e($news->source); ?>">
									</object>
								</div>
								<div class="content-list-title"><?php echo e($news->judul); ?></div>
								
								<div class="content-list-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum, iusto excepturi quibusdam ipsa at sunt. Voluptate ipsa fuga aliquam est quaerat. Consequatur cupiditate distinctio expedita quidem quibusdam, et cumque rem.</div>
								<div class="content-list-kategori"><?php echo e(App\Model\Kategori::detail($news->id_kategori)->nama_kategori); ?></div>
							</div>
						<?php elseif($news->source_type == 'embed'): ?>
							<div class="content-list <?php echo e($news->source_type); ?>" onclick="linked('<?php echo e(url('view/'.App\Model\Kategori::detail($news->id_kategori)->nama_kategori.'/'.$news->url)); ?>');">
								<div class="content-video">
									<div class="embed">
										<?php echo $news->source; ?>

									</div>
								</div>
								<div class="content-list-title"><?php echo e($news->judul); ?></div>
								
								<div class="content-list-desc">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum, iusto excepturi quibusdam ipsa at sunt. Voluptate ipsa fuga aliquam est quaerat. Consequatur cupiditate distinctio expedita quidem quibusdam, et cumque rem.</div>
								<div class="content-list-kategori"><?php echo e(App\Model\Kategori::detail($news->id_kategori)->nama_kategori); ?></div>
							</div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-md-3 content-right">
				<div class="list-berita-title">Mamuju TV</div>
				<div class="list-berita">
					<div class="content-list">
						<img src="<?php echo e(asset('images/watch.jpg')); ?>" alt="" class="content-list-img">
						<div class="content-list-kategori">PIDANA</div>
						<div class="content-list-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
					</div>
					<div class="content-list">
						<img src="<?php echo e(asset('images/watch.jpg')); ?>" alt="" class="content-list-img">
						<div class="content-list-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
					</div>
					<div class="content-list">
						<img src="<?php echo e(asset('images/watch.jpg')); ?>" alt="" class="content-list-img">
						<div class="content-list-title">Lorem ipsum dolor sit amet, consectetur adipisicing elit</div>
					</div>
				</div>
				<div class="list-berita-title">Terpopuler</div>
				<div class="list-berita">
					<?php
					$popular_no = 0;
					?>
					<?php $__currentLoopData = $berita_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($popular_no == 0): ?>
							<a href="<?php echo e(url('view/'.App\Model\Kategori::detail($popular->id_kategori)->nama_kategori.'/'.$popular->url)); ?>" class="content-list">
								<img src="<?php echo e($popular->source); ?>" alt="" class="content-list-img">
								<div class="content-list-kategori"><?php echo e(App\Model\Kategori::detail($popular->id_kategori)->nama_kategori); ?></div>
								<div class="content-list-title"><?php echo e($popular->judul); ?></div>
							</a>
						<?php else: ?>
							<a href="<?php echo e(url('view/'.App\Model\Kategori::detail($popular->id_kategori)->nama_kategori.'/'.$popular->url)); ?>" class="content-list">
								<img src="<?php echo e($popular->source); ?>" alt="" class="content-list-img">
								<div class="content-list-title"><?php echo e($popular->judul); ?></div>
							</a>
						<?php endif; ?>
					<?php
					$popular_no = $popular_no + 1;
					?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</body>
<footer>
	<script src="<?php echo e(asset('js/lib/bootstrap/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/mnews/mnews.js')); ?>"></script>
</footer>
</html>