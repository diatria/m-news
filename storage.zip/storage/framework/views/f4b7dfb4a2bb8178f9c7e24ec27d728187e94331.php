<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  /* Note: Try to remove the following lines to see the effect of CSS positioning */
  .affix {
      top: 0;
      width: 100%;
      z-index: 9999 !important;
  }

  .affix + .container-fluid {
      padding-top: 70px;
  }

  .center ul{
    width: -moz-fit-content;
    width: -webkit-fit-content;
    width: fit-content;
    margin: auto;
  }

  input[type=text] {
    width: 70%;
    box-sizing: border-box;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 11px;
    background-color: white;
    background-position: 10px 10px; 
    background-repeat: no-repeat;
    padding: 12px 20px 12px 40px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
  }

  input[type=text]:focus {
    width: 90%;
  }

  button{
    width: 10%;
    padding: 10px;
    background: #2196F3;
    color: white;
    font-size: 14px;
    border: none;
    cursor: pointer;
    box-sizing: border-box;
    border: 1px solid #ccc;
    border-radius: 4px;
    -webkit-transition: width 0.4s ease-in-out;
    transition: width 0.4s ease-in-out;
  }



.topnav {
  overflow: visible;
  background-color: #333;
  text-align: center;
  padding: 15px;
  font-size: 12px;
  height: 10px;

}

.topnav a {

  color: #f2f2f2;
  padding: 6px 8px;
  text-decoration: none;
  font-size: 12px;
}

.topnav a:hover {
  color: red;
}

.topnav a.active {
  color: green;
}

.header{
  padding: 10px;
  background-color: rgb(29, 112, 100);
}

.konten{
  text-align: center;
    margin-top: -20px;
  padding: 10px;
}

  </style>
</head>
<body>


<!-- A. Bagian Header 
======================================================================================================================================== -->


<div class="container-fluid header">
    <div class="col-sm-4">
      <center><img class="visible-lg visible-md visible-sm" src="logo.png" ></center>

    </div>


    <div class="col-sm-5">
      <br class="visible-lg visible-md visible-sm">
      <form class="visible-lg visible-md visible-sm">
        <p><center><input type="text" name="search" placeholder="Search.."><button type="submit"><i class="fa fa-search"></i></button></center></p>
      </form>
    </div>

    <div class="col-sm-2">
     <br class="visible-lg visible-md visible-sm">
     <br class="visible-lg visible-md visible-sm">
    <center>
      <p class="visible-lg visible-md visible-sm" style="color: orange;">
        <a href="#" style="color: orange;">Login</a>  |  <a href="#" style="color: orange;">Register</a>
      </p>
    </center>
    </div>
</div>


<nav class="navbar navbar-inverse visible-xs" data-spy="affix" data-offset-top="197">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                       
      </button>
   </div>
      <a class="visible-xs" href="#"><img src="logo.png" width="50%"></a>


    <div class="row">
      <div class="collapse navbar-collapse navbar-center " id="myNavbar">
        <ul class="nav navbar-nav">
          <li class="active"><a href="#">Home</a></li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">NEWS
            <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="#">Politik</a></li>
              <li><a href="#">Hukum</a></li>
              <li><a href="#">Ekonomi Bisnis</a></li>
              <li><a href="#">Kesehatan</a></li>
              <li><a href="#">Pendidikan</a></li>
              <li><a href="#">Sosial Budaya</a></li>
            </ul>
          </li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">RAGAM
            <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="#">In Depth</a></li>
              <li><a href="#">Gaya Hidup</a></li>
              <li><a href="#">Teknologi</a></li>
              <li><a href="#">Otomotif</a></li>
              <li><a href="#">Future</a></li>
              <li><a href="#">Netizen</a></li>
            </ul>
          </li>
          <li><a href="#">OLAHRAGA</a></li>
          <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">DAERAH
            <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="#">Mamuju</a></li>
              <li><a href="#">Mamuju Tengah</a></li>
              <li><a href="#">Mamuju Utara</a></li>
              <li><a href="#">Majene</a></li>
              <li><a href="#">Polman</a></li>
              <li><a href="#">Mamasa</a></li>
            </ul>
          </li>
          <li><a href="#">INFOGRAFIS</a></li>
          <li><a href="#">TOKOH</a></li>
          <li><a href="#">OPINI</a></li>
          <li><a href="#">FOTO</a></li>
          <li><a href="#">MAMUJU TV</a></li>
          <li><a href="#">DESAKU</a></li>
          <li><a href="#">WISATA</a></li>
        </ul>
        <ul class="visible-xs nav navbar-nav">
          <li><a>Login</a></li>
          <li><a>Register</a></li>
        </ul>
      </div>
    </div>
  </div>
</nav> 

<div class="navbar navbar-inverse topnav visible-lg visible-md visible-sm" data-spy="affix" data-offset-top="197">
          <a href="#home">HOME</a>
          <a href="#">NEWS</a>
          <a href="#">RAGAM</a>
          <a href="#">OLAHRAGA</a>
          <a href="#">DAERAH</a>
          <a href="#">INFOGRAFIS</a>
          <a href="#">TOKOH</a>
          <a href="#">OPINI</a>
          <a href="#">FOTO</a>
          <a href="#">MAMUJU TV</a>
          <a href="#">DESAKU</a>
          <a href="#">WISATA</a>
</div>

<!-- 1. Bagian Seluruh Konten
========================================================================================================================================= -->
<div class="container-fluid konten" style="background-color: #CCCCCC;">

  <!--// 1.1 Bagian iklan 1
  ======================================================================================================================================= -->
  <div class="col-sm-1 iklan13">
    <img src="iklan13.png" width="100%" height="auto">
  </div>

  <!--// 1.2 Bagian Seluruh Konte Tengah
  ============================================ height="auto" -->
  <div class="col-sm-10">

    <div class="row iklan2">
      <img src="iklan2.png" width="100%" height="auto">
    </div>  

<br>    

    <!--// 1.2.1 Bagian Konten Isi
    ===================================================================================================================================== -->
    <div class="col-sm-9">
      
      <!-- INI SLIDE IMAGE 
      ==========================================================================================================-->
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" style="height: 350px">
          <?php
            $no = 0;
          ?>
          <?php $__currentLoopData = $berita_slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php if($no == 0): ?>
            <a href="" class="item active">
          <?php else: ?>
            <a href="" class="item">
          <?php endif; ?>

            <?php if($slider->source_type == 'gambar'): ?>
            <img src="<?php echo e($slider->source); ?>" alt="Los Angeles" style="width:100%; height: 350px;">
            <?php elseif($slider->source_type == 'video'): ?>
            <object width="420" height="315" data="<?php echo e($slider->source); ?>">
            </object>
            <?php endif; ?>
            <div class="carousel-caption">
              <h3>Los Angeles</h3>
              <p>LA is always so much fun!</p>
            </div>
          </a>
          <?php
          $no = $no + 1
          ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Left and right controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
          <span class="glyphicon glyphicon-chevron-left"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
          <span class="glyphicon glyphicon-chevron-right"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
<br>

      <!-- INI LIST 4 IMAGE 
      ==========================================================================================================-->

      <div class="row">
        <div class="col-md-3">
          <div class="thumbnail">
            <a href="/w3images/lights.jpg" target="_blank">
              <img src="/w3images/lights.jpg" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-3">
          <div class="thumbnail">
            <a href="/w3images/nature.jpg" target="_blank">
              <img src="/w3images/nature.jpg" alt="Nature" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-3">
          <div class="thumbnail">
            <a href="/w3images/fjords.jpg" target="_blank">
              <img src="/w3images/fjords.jpg" alt="Fjords" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-3">
          <div class="thumbnail">
            <a href="/w3images/fjords.jpg" target="_blank">
              <img src="/w3images/fjords.jpg" alt="Fjords" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
      </div>      

      <!-- INI Iklan 6 
      ==========================================================================================================-->
      <div class="row iklan6">
        <img src="iklan6.png" width="95%" height="60px">
      </div>

<hr />
      <!-- INI berita Infografis 
      ==========================================================================================================-->
      <h4 style="text-align: left;"><a><u>INFO GRAFIS</u></a></h4>
      
      <div class="row">
        <div class="col-md-4">
          <div class="thumbnail">
            <a href="/w3images/lights.jpg" target="_blank">
              <img src="slide/gbr1.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <a href="/w3images/nature.jpg" target="_blank">
              <img src="slide/gbr2.png" alt="Nature" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <a href="/w3images/fjords.jpg" target="_blank">
              <img src="slide/gbr3.png" alt="Fjords" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <a href="/w3images/fjords.jpg" target="_blank">
              <img src="slide/gbr3.png" alt="Fjords" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
         <div class="col-md-4">
          <div class="thumbnail">
            <a href="/w3images/lights.jpg" target="_blank">
              <img src="slide/gbr2.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="thumbnail">
            <a href="/w3images/nature.jpg" target="_blank">
              <iframe width="100%" height="auto" src="https://www.youtube.com/embed/KqwTm80y-Ok" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>
      </div>      

      <!-- INI iklan7 
      ==========================================================================================================-->
      <div class="row iklan7">
        <img src="iklan7.png" width="95%" height="60px">
      </div>

<hr>
      <!-- INI berita Berita Terkini 
      ==========================================================================================================-->
      <h4 style="text-align: left;"><a><u>BERITA TERKINI</u></a></h4>
        <table style="text-align: left;    display: table; border-collapse: separate;">
          <tr>
            <td colspan="2" rowspan="2" style="clear: both; padding: 0; margin: 0;" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>          
          <tr>
            <td colspan="2" rowspan="2" ></td>
            <td></td>
          </tr> 
        </table>

    <!--// 1.2.2 Bagian video 1
    ==================================================================================================== -->
        <table style="text-align: left; border-spacing: 10px;   display: table; border-collapse: separate;">
          <tr>
            <td colspan="2" rowspan="2" width="70%" height="auto"><iframe width="100%" height="300px" src="https://www.youtube.com/embed/KqwTm80y-Ok" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td width="30%">news  |  15/12/2017</td>
          </tr>
        </table>

     <!--// 1.2.2 Bagian Berita Terkini
    ==================================================================================================== -->
       <table style="text-align: left; border-spacing: 10px;   display: table; border-collapse: separate;">
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr> 
        </table>

<hr>

      <!-- INI SLIDE IMAGE 
      ==========================================================================================================-->
      <h4 style="text-align: left;"><a><u>IMAGES</u></a></h4>

      <div class="w3-content" style="max-width:800px">
        <img class="mySlides" src="slide/gbr1.png" style="width:100%">
        <img class="mySlides" src="slide/gbr2.png" style="width:100%">
        <img class="mySlides" src="slide/gbr3.png" style="width:100%">
      </div>

      <div class="w3-center">
        <button class="w3-button demo" onclick="currentDiv(1)">1</button> 
        <button class="w3-button demo" onclick="currentDiv(2)">2</button> 
        <button class="w3-button demo" onclick="currentDiv(3)">3</button> 
      </div>

      <script>
      var slideIndex = 1;
      showDivs(slideIndex);

      function plusDivs(n) {
        showDivs(slideIndex += n);
      }

      function currentDiv(n) {
        showDivs(slideIndex = n);
      }

      function showDivs(n) {
        var i;
        var x = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        if (n > x.length) {slideIndex = 1}    
        if (n < 1) {slideIndex = x.length}
        for (i = 0; i < x.length; i++) {
           x[i].style.display = "none";  
        }
        for (i = 0; i < dots.length; i++) {
           dots[i].className = dots[i].className.replace(" w3-red", "");
        }
        x[slideIndex-1].style.display = "block";  
        dots[slideIndex-1].className += " w3-red";
      }
      </script>

<hr>
      <!-- INI berita Berita Terkini 
      ==========================================================================================================-->
      <h4 style="text-align: left;"><a><u>BERITA TERKINI</u></a></h4>
        <table style="text-align: left; border-spacing: 10px;   display: table; border-collapse: separate;">
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>          
          <tr>
            <td colspan="2" rowspan="2" ></td>
            <td></td>
          </tr> 
        </table>

    <!--// 1.2.2 Bagian video 1
    ==================================================================================================== -->
        <table style="text-align: left; border-spacing: 10px;   display: table; border-collapse: separate;">
          <tr>
            <td colspan="2" rowspan="2" width="70%" height="auto"><iframe width="100%" height="300px" src="https://www.youtube.com/embed/KqwTm80y-Ok" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td width="30%">news  |  15/12/2017</td>
          </tr>
        </table>

     <!--// 1.2.2 Bagian Berita Terkini
    ==================================================================================================== -->
       <table style="text-align: left; border-spacing: 10px;   display: table; border-collapse: separate;">
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr>
          <tr>
            <td colspan="2" rowspan="2" ><img src="beritaterkini.png"></td>
            <td><a href="#"><h2>Emil Dardak Minta Baliho Bergambar Khofifah-Emil Diturunkan</h2></a></td>
          </tr>
          <tr>
            <td>news  |  15/12/2017</td>
          </tr> 
        </table>


    </div>

    <!--// 1.2.2 Bagian Sidebar
    ==================================================================================================== -->
    <div class="col-sm-3">
      <img src="iklan4.png" alt="Chicago" style="width:100%;">
      <img src="iklan5.png" alt="Chicago" style="width:100%;">

          <div class="thumbnail">
            <a href="/beritaterkini.png" target="_blank">
              <img src="beritaterkini.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>


    </div>

        <div class="col-md-3">
          <div class="thumbnail">
            <a href="/beritaterkini.png" target="_blank">
              <img src="beritaterkini.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
          <div class="thumbnail">
            <a href="/beritaterkini.png" target="_blank">
              <img src="beritaterkini.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
          <div class="thumbnail">
            <a href="/beritaterkini.png" target="_blank">
              <img src="beritaterkini.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
          <div class="thumbnail">
            <a href="/beritaterkini.png" target="_blank">
              <img src="beritaterkini.png" alt="Lights" style="width:100%">
              <div class="caption">
                <p>Lorem ipsum donec id elit non mi porta gravida at eget metus.</p>
              </div>
            </a>
          </div>
        </div>


  </div>

  <!--// 1.3. Konten Iklan 2
  ======================================================================================================= -->
  <div class="col-sm-1">
    <img src="iklan13.png" width="100%" height="auto">    
  </div>


</div>

<!-- // Bagian Footer
========================================================================================================= -->
<div class="footer">
  
  <div class="col-sm-12" style="background-color: grey;">Copyiright</div>
</div>

</body>
</html>
